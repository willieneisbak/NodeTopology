
function main()


% note this function will carry out all demos associated with the paper "Embedding Nodes via their Local Network Topology for use in Machine Learning"

% each demo takes a little while for the nodes to be embedded

% this function should be called from within the nodetop_forDDM directory

addpath(genpath('func'))


demo5_dolphinSocialNetwork();
demo6_dickensCopperfield();
demo7_footballTeams();