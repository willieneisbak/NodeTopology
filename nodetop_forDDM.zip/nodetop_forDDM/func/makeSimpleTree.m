
function tree = makeSimpleTree()

% this function returns a simple tree graph


tree(1,2) = 1;
tree(1,3) = 1;
tree(1,4) = 1;

tree(2,1) = 1;
tree(2,5) = 1;

tree(3,1) = 1;
tree(3,6) = 1;
tree(3,7) = 1;

tree(4,1) = 1;
tree(4,8) = 1;

tree(5,2) = 1;
tree(5,9) = 1;
tree(5,10) = 1;
tree(5,11) = 1;

tree(6,3) = 1;
tree(6,12) = 1;

tree(7,3) = 1;
tree(7,13) = 1;

tree(8,4) = 1;
tree(8,14) = 1;
tree(8,15) = 1;

tree(9,5) = 1;

tree(10,5) = 1;

tree(11,5) = 1;

tree(12,6) = 1;

tree(13,7) = 1;

tree(14,8) = 1;

tree(15,8) = 1;